#include <stdio.h>
#include <iostream>

int begin() {
    system("./Internal/functionality/core.out");
    return 0;
}

int main() {
    int process;
    process = begin();
    return 0;
}